from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("database.db")

SAMPLE_QUESTIONS = [
    {
        "subject": "Python",
        "topic": "Variables",
        "difficulty": "Easy",
        "question": "Which symbol is used to assign a value to a variable in Python?",
        "options": ["==", "=", "!=", ":"],
        "answer": "=",
        "explanation": "A single equals sign (=) assigns a value to a variable."
    },
    {
        "subject": "Python",
        "topic": "Variables",
        "difficulty": "Easy",
        "question": "Which is a valid Python variable name?",
        "options": ["2name", "first_name", "first-name", "class"],
        "answer": "first_name",
        "explanation": "A variable name can contain letters, digits and underscores, but cannot start with a digit or be a Python keyword."
    },
    {
        "subject": "Python",
        "topic": "Data Types",
        "difficulty": "Easy",
        "question": "What is the data type of 10 in Python?",
        "options": ["str", "float", "int", "bool"],
        "answer": "int",
        "explanation": "10 is a whole number, so its type is int."
    },
    {
        "subject": "Computer Science",
        "topic": "Computers",
        "difficulty": "Easy",
        "question": "Which component is often called the brain of the computer?",
        "options": ["Monitor", "CPU", "Keyboard", "Mouse"],
        "answer": "CPU",
        "explanation": "The CPU processes instructions and controls computer operations."
    }
]

def get_db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection

def initialize_database():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT NOT NULL,
                subject TEXT NOT NULL,
                topic TEXT NOT NULL,
                score INTEGER NOT NULL,
                total INTEGER NOT NULL
            )
        """)

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if name:
            with get_db() as db:
                db.execute("INSERT OR IGNORE INTO students (name) VALUES (?)", (name,))
            session["student"] = name
            return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "student" not in session:
        return redirect(url_for("login"))
    with get_db() as db:
        results = db.execute(
            "SELECT * FROM results WHERE student_name = ? ORDER BY id DESC",
            (session["student"],)
        ).fetchall()
    return render_template("dashboard.html", student=session["student"], results=results)

@app.route("/learn")
def learn():
    if "student" not in session:
        return redirect(url_for("login"))
    return render_template("learning.html")

@app.route("/quiz", methods=["GET", "POST"])
def quiz():
    if "student" not in session:
        return redirect(url_for("login"))

    subject = request.values.get("subject", "Python")
    topic = request.values.get("topic", "Variables")
    questions = [q for q in SAMPLE_QUESTIONS if q["subject"] == subject and q["topic"] == topic]

    if request.method == "POST":
        score = 0
        review = []
        for index, question in enumerate(questions):
            selected = request.form.get(f"q{index}", "")
            correct = selected == question["answer"]
            score += int(correct)
            review.append({**question, "selected": selected, "correct": correct})
        with get_db() as db:
            db.execute(
                "INSERT INTO results (student_name, subject, topic, score, total) VALUES (?, ?, ?, ?, ?)",
                (session["student"], subject, topic, score, len(questions))
            )
        return render_template("result.html", score=score, total=len(questions), review=review)

    return render_template("quiz.html", subject=subject, topic=topic, questions=questions)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    initialize_database()
    app.run(debug=True)
