# Personalized Learning and Quiz Generator

A beginner-friendly Flask web application starter project.

## Requirements
- Python 3.10 or newer
- Visual Studio Code

## Setup on Windows

1. Open this folder in VS Code.
2. Open Terminal → New Terminal.
3. Create and activate a virtual environment:

   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   ```

4. Install Flask:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Start the website:

   ```powershell
   python app.py
   ```

6. Open the local address printed in the terminal (usually http://127.0.0.1:5000).

## Current starter features
- Student name-based demo login
- Learning dashboard
- Sample learning materials
- Sample multiple-choice quiz
- Instant score and explanations
- Quiz result history stored in SQLite

## Important next improvements
This is a starter version, not the finished project. Next we should add proper password authentication, more topics and questions, difficulty selection, adaptive recommendations, and stronger validation. The sample login is for local demonstration only and is not production-ready.
